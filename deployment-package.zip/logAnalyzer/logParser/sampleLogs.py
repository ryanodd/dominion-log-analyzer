logStr = "\
Game #56810461, unrated.\n\
\n\
J starts with 7 Coppers.\n\
J starts with 3 Estates.\n\
L starts with 7 Coppers.\n\
L starts with 3 Estates.\n\
J shuffles their deck.\n\
J draws 3 Coppers and 2 Estates.\n\
L shuffles their deck.\n\
L draws 5 cards.\n\
\n\
Turn 1 - Jazzercise\n\
J plays 3 Coppers. (+$3)\n\
J buys and gains a Chapel.\n\
J draws 4 Coppers and an Estate.\n\
\n\
Turn 1 - Lord Rattington\n\
L plays 3 Coppers. (+$3)\n\
L buys and gains a Chapel.\n\
L draws 5 cards.\n\
\n\
Turn 2 - Jazzercise\n\
J plays 4 Coppers. (+$4)\n\
J buys and gains a Silver.\n\
J shuffles their deck.\n\
J draws a Copper, a Silver, 2 Estates and a Chapel.\n\
\n\
Turn 2 - Lord Rattington\n\
L plays 4 Coppers. (+$4)\n\
L buys and gains a Silver.\n\
L shuffles their deck.\n\
L draws 5 cards.\n\
\n\
Turn 3 - Jazzercise\n\
J plays a Chapel.\n\
J trashes 2 Estates.\n\
J plays a Silver and a Copper. (+$3)\n\
J buys and gains a Village.\n\
J draws 4 Coppers and an Estate.\n\
\n\
Turn 3 - Lord Rattington\n\
L plays a Chapel.\n\
L trashes 4 Coppers.\n\
L draws 5 cards.\n\
\n\
Turn 4 - Jazzercise\n\
J plays 4 Coppers. (+$4)\n\
J buys and gains a Village.\n\
J shuffles their deck.\n\
J draws 2 Coppers, an Estate and 2 Villages.\n\
\n\
Turn 4 - Lord Rattington\n\
L plays 3 Coppers. (+$3)\n\
L buys and gains a Silver.\n\
L shuffles their deck.\n\
L draws 5 cards.\n\
\n\
Turn 5 - Jazzercise\n\
J plays a Village.\n\
J draws a Copper.\n\
J gets +2 Actions.\n\
J plays a Village.\n\
J draws a Copper.\n\
J gets +2 Actions.\n\
J plays 4 Coppers. (+$4)\n\
J buys and gains a Silver.\n\
J draws 3 Coppers, a Silver and a Chapel.\n\
\n\
Turn 5 - Lord Rattington\n\
L plays 2 Silvers and a Copper. (+$5)\n\
L buys and gains a Witch.\n\
L shuffles their deck.\n\
L draws 5 cards.\n\
\n\
Turn 6 - Jazzercise\n\
J plays a Chapel.\n\
J trashes 2 Coppers.\n\
J plays a Silver and a Copper. (+$3)\n\
J buys and gains a Village.\n\
J shuffles their deck.\n\
J draws a Copper, a Silver, an Estate, a Chapel and a Village.\n\
\n\
Turn 6 - Lord Rattington\n\
L plays a Witch.\n\
L draws 2 cards.\n\
J gains a Curse.\n\
L plays a Silver and 3 Coppers. (+$5)\n\
L buys and gains a Laboratory.\n\
L shuffles their deck.\n\
L draws 5 cards.\n\
\n\
Turn 7 - Jazzercise\n\
J plays a Village.\n\
J draws a Village.\n\
J gets +2 Actions.\n\
J plays a Village.\n\
J draws a Silver.\n\
J gets +2 Actions.\n\
J plays a Chapel.\n\
J trashes an Estate.\n\
J plays 2 Silvers and a Copper. (+$5)\n\
J buys and gains a Witch.\n\
J draws 4 Coppers and a Village.\n\
\n\
Turn 7 - Lord Rattington\n\
L plays a Laboratory.\n\
L draws 2 cards.\n\
L gets +1 Action.\n\
L plays a Silver and 3 Coppers. (+$5)\n\
L buys and gains a Silver.\n\
L shuffles their deck.\n\
L draws 5 cards.\n\
\n\
Turn 8 - Jazzercise\n\
J plays a Village.\n\
J shuffles their deck.\n\
J draws a Silver.\n\
J gets +2 Actions.\n\
J plays a Silver and 4 Coppers. (+$6)\n\
J buys and gains a Witch.\n\
J draws a Curse, a Silver, a Chapel, a Village and a Witch.\n\
\n\
Turn 8 - Lord Rattington\n\
L plays a Witch.\n\
L draws 2 cards.\n\
J gains a Curse.\n\
L plays 2 Silvers. (+$4)\n\
L buys and gains a Silver.\n\
L draws 5 cards.\n\
\n\
Turn 9 - Jazzercise\n\
J plays a Village.\n\
J draws a Copper.\n\
J gets +2 Actions.\n\
J plays a Witch.\n\
J shuffles their deck.\n\
J draws a Silver and a Village.\n\
L gains a Curse.\n\
J plays a Village.\n\
J draws a Copper.\n\
J gets +2 Actions.\n\
J plays a Chapel.\n\
J trashes a Curse and a Copper.\n\
J plays 2 Silvers and a Copper. (+$5)\n\
J buys and gains a Witch.\n\
J draws 3 Coppers, a Village and a Witch.\n\
\n\
Turn 9 - Lord Rattington\n\
L plays a Laboratory.\n\
L shuffles their deck.\n\
L draws 2 cards.\n\
L gets +1 Action.\n\
L plays a Chapel.\n\
L trashes 3 Coppers and an Estate.\n\
L plays a Silver. (+$2)\n\
L buys and gains a Moat.\n\
L draws 5 cards.\n\
\n\
Turn 10 - Jazzercise\n\
J plays a Village.\n\
J draws a Curse.\n\
J gets +2 Actions.\n\
J plays a Witch.\n\
J shuffles their deck.\n\
J draws a Copper and a Witch.\n\
L gains a Curse.\n\
J plays a Witch.\n\
J draws 2 Villages.\n\
L gains a Curse.\n\
J plays 4 Coppers. (+$4)\n\
J buys and gains a Village.\n\
J shuffles their deck.\n\
J draws a Copper, 2 Silvers, a Chapel and a Witch.\n\
\n\
Turn 10 - Lord Rattington\n\
L plays a Witch.\n\
L draws 2 cards.\n\
J gains a Curse.\n\
L plays 3 Silvers. (+$6)\n\
L buys and gains a Gold.\n\
L shuffles their deck.\n\
L draws 5 cards.\n\
\n\
Turn 11 - Jazzercise\n\
J plays a Witch.\n\
J draws 2 Coppers.\n\
L gains a Curse.\n\
J plays 2 Silvers and 3 Coppers. (+$7)\n\
J buys and gains a Gold.\n\
J draws a Copper, 3 Villages and a Witch.\n\
\n\
Turn 11 - Lord Rattington\n\
L plays a Laboratory.\n\
L draws 2 cards.\n\
L gets +1 Action.\n\
L plays a Witch.\n\
L draws 2 cards.\n\
J gains a Curse.\n\
L plays 2 Silvers. (+$4)\n\
L buys and gains a Silver.\n\
L draws 5 cards.\n\
\n\
Turn 12 - Jazzercise\n\
J plays a Village.\n\
J draws a Witch.\n\
J gets +2 Actions.\n\
J plays a Village.\n\
J draws a Village.\n\
J gets +2 Actions.\n\
J plays a Village.\n\
J draws a Curse.\n\
J gets +2 Actions.\n\
J plays a Village.\n\
J shuffles their deck.\n\
J draws a Gold.\n\
J gets +2 Actions.\n\
J plays a Witch.\n\
L reacts with a Moat.\n\
J draws a Curse and a Copper.\n\
J plays a Witch.\n\
L reacts with a Moat.\n\
J draws a Curse and a Silver.\n\
J plays a Gold, a Silver and 2 Coppers. (+$7)\n\
J buys and gains a Gold.\n\
J draws 2 Coppers, a Silver, a Chapel and a Witch.\n\
\n\
Turn 12 - Lord Rattington\n\
L plays a Moat.\n\
L shuffles their deck.\n\
L draws 2 cards.\n\
L plays a Gold and 2 Silvers. (+$7)\n\
L buys and gains a Gold.\n\
L draws 5 cards.\n\
\n\
Turn 13 - Jazzercise\n\
J plays a Witch.\n\
J shuffles their deck.\n\
J draws a Curse and a Village.\n\
L gains a Curse.\n\
J plays a Silver and 2 Coppers. (+$4)\n\
J buys and gains a Village.\n\
J draws a Curse, a Copper, 2 Golds and a Village.\n\
\n\
Turn 13 - Lord Rattington\n\
L plays a Chapel.\n\
L trashes 2 Curses.\n\
L plays 2 Silvers. (+$4)\n\
L buys and gains a Silver.\n\
L shuffles their deck.\n\
L draws 5 cards.\n\
\n\
Turn 14 - Jazzercise\n\
J plays a Village.\n\
J draws a Silver.\n\
J gets +2 Actions.\n\
J plays 2 Golds, a Silver and a Copper. (+$9)\n\
J buys and gains a Province.\n\
J draws a Curse, a Copper, a Village and 2 Witches.\n\
\n\
Turn 14 - Lord Rattington\n\
L plays a Witch.\n\
L draws 2 cards.\n\
J gains a Curse.\n\
L plays 2 Silvers. (+$4)\n\
L buys and gains a Silver.\n\
L draws 5 cards.\n\
\n\
Turn 15 - Jazzercise\n\
J plays a Village.\n\
J draws a Village.\n\
J gets +2 Actions.\n\
J plays a Village.\n\
J shuffles their deck.\n\
J draws a Village.\n\
J gets +2 Actions.\n\
J plays a Village.\n\
J draws a Curse.\n\
J gets +2 Actions.\n\
J plays a Witch.\n\
J draws a Copper and a Village.\n\
J plays a Village.\n\
J draws a Silver.\n\
J gets +2 Actions.\n\
J plays a Witch.\n\
J draws a Gold and a Chapel.\n\
J plays a Chapel.\n\
J trashes 2 Curses and a Copper.\n\
J plays a Gold, a Silver and a Copper. (+$6)\n\
J buys and gains a Gold.\n\
J draws a Curse, a Copper, a Silver, a Gold and a Village.\n\
\n\
Turn 15 - Lord Rattington\n\
L plays a Laboratory.\n\
L draws 2 cards.\n\
L gets +1 Action.\n\
L plays a Chapel.\n\
L plays 2 Golds and 3 Silvers. (+$12)\n\
L buys and gains a Province.\n\
L shuffles their deck.\n\
L draws 5 cards.\n\
\n\
Turn 16 - Jazzercise\n\
J plays a Village.\n\
J draws a Curse.\n\
J gets +2 Actions.\n\
J plays a Gold, a Silver and a Copper. (+$6)\n\
J buys and gains a Laboratory.\n\
J shuffles their deck.\n\
J draws a Curse, a Copper, a Gold, a Province and a Witch.\n\
\n\
Turn 16 - Lord Rattington\n\
L plays 3 Silvers. (+$6)\n\
L buys and gains a Gold.\n\
L draws 5 cards.\n\
\n\
Turn 17 - Jazzercise\n\
J plays a Witch.\n\
J draws a Gold and a Laboratory.\n\
J plays 2 Golds and a Copper. (+$7)\n\
J buys and gains a Gold.\n\
J draws a Copper, a Silver and 3 Villages.\n\
\n\
Turn 17 - Lord Rattington\n\
L plays a Witch.\n\
L draws 2 cards.\n\
L plays a Gold and 2 Silvers. (+$7)\n\
L buys and gains a Gold.\n\
L draws 5 cards.\n\
\n\
Turn 18 - Jazzercise\n\
J plays a Village.\n\
J draws a Copper.\n\
J gets +2 Actions.\n\
J plays a Village.\n\
J draws a Village.\n\
J gets +2 Actions.\n\
J plays a Village.\n\
J draws a Witch.\n\
J gets +2 Actions.\n\
J plays a Village.\n\
J draws a Chapel.\n\
J gets +2 Actions.\n\
J plays a Witch.\n\
L reacts with a Moat.\n\
J draws a Silver and a Village.\n\
J plays a Village.\n\
J draws a Curse.\n\
J gets +2 Actions.\n\
J plays a Chapel.\n\
J trashes a Curse and 2 Coppers.\n\
J plays 2 Silvers. (+$4)\n\
J buys and gains a Village.\n\
J shuffles their deck.\n\
J draws a Silver, a Gold, a Laboratory, a Village and a Witch.\n\
\n\
Turn 18 - Lord Rattington\n\
L plays a Laboratory.\n\
L draws 2 cards.\n\
L gets +1 Action.\n\
L plays a Moat.\n\
L shuffles their deck.\n\
L draws 2 cards.\n\
L plays 2 Golds and 3 Silvers. (+$12)\n\
L buys and gains a Province.\n\
L draws 5 cards.\n\
\n\
Turn 19 - Jazzercise\n\
J plays a Village.\n\
J draws a Silver.\n\
J gets +2 Actions.\n\
J plays a Laboratory.\n\
J draws a Village and a Witch.\n\
J gets +1 Action.\n\
J plays a Village.\n\
J draws a Curse.\n\
J gets +2 Actions.\n\
J plays a Witch.\n\
J draws a Copper and a Chapel.\n\
J plays a Witch.\n\
J draws a Gold and a Province.\n\
J plays a Chapel.\n\
J trashes a Curse and a Copper.\n\
J plays 2 Golds and 2 Silvers. (+$10)\n\
J buys and gains a Province.\n\
J draws a Gold, 3 Villages and a Witch.\n\
\n\
Turn 19 - Lord Rattington\n\
L plays a Witch.\n\
L draws 2 cards.\n\
L plays a Gold and 2 Silvers. (+$7)\n\
L buys and gains a Duchy.\n\
L draws 5 cards.\n\
\n\
Turn 20 - Jazzercise\n\
J plays a Village.\n\
J draws a Gold.\n\
J gets +2 Actions.\n\
J plays a Village.\n\
J draws a Village.\n\
J gets +2 Actions.\n\
J plays a Village.\n\
J shuffles their deck.\n\
J draws a Gold.\n\
J gets +2 Actions.\n\
J plays a Village.\n\
J draws a Gold.\n\
J gets +2 Actions.\n\
J plays a Witch.\n\
J draws a Silver and a Witch.\n\
J plays a Witch.\n\
J draws 2 Provinces.\n\
J plays 4 Golds and a Silver. (+$14)\n\
J buys and gains a Province.\n\
J draws a Silver, a Chapel, a Laboratory and 2 Villages.\n\
\n\
Turn 20 - Lord Rattington\n\
L plays a Chapel.\n\
L trashes a Curse.\n\
L plays a Gold and 2 Silvers. (+$7)\n\
L buys and gains a Duchy.\n\
L shuffles their deck.\n\
L draws 5 cards.\n\
\n\
Turn 21 - Jazzercise\n\
J plays a Village.\n\
J draws a Witch.\n\
J gets +2 Actions.\n\
J plays a Village.\n\
J shuffles their deck.\n\
J draws a Village.\n\
J gets +2 Actions.\n\
J plays a Village.\n\
J draws a Silver.\n\
J gets +2 Actions.\n\
J plays a Laboratory.\n\
J draws a Province and a Witch.\n\
J gets +1 Action.\n\
J plays a Witch.\n\
J draws a Province and a Witch.\n\
J plays a Witch.\n\
J draws a Gold and a Province.\n\
J plays a Witch.\n\
J draws 2 Golds.\n\
J plays 3 Golds and 2 Silvers. (+$13)\n\
J buys and gains a Province.\n\
J shuffles their deck.\n\
J draws 2 Golds and 3 Villages.\n\
\n\
Turn 21 - Lord Rattington\n\
L plays 3 Silvers. (+$6)\n\
L buys and gains a Duchy.\n\
L draws 5 cards.\n\
\n\
Turn 22 - Jazzercise\n\
J plays a Village.\n\
J draws a Witch.\n\
J gets +2 Actions.\n\
J plays a Village.\n\
J draws a Witch.\n\
J gets +2 Actions.\n\
J plays a Village.\n\
J draws a Gold.\n\
J gets +2 Actions.\n\
J plays a Witch.\n\
J draws a Chapel and a Village.\n\
J plays 3 Golds. (+$9)\n\
J buys and gains a Province.\n\
J draws a Silver, a Laboratory, 2 Villages and a Witch.\n\
\n\
Turn 22 - Lord Rattington\n\
L plays 2 Golds. (+$6)\n\
L buys and gains a Duchy.\n\
L draws 5 cards.\n\
\n\
Turn 23 - Jazzercise\n\
J plays a Village.\n\
J draws a Silver.\n\
J gets +2 Actions.\n\
J plays a Village.\n\
J draws a Province.\n\
J gets +2 Actions.\n\
J plays a Laboratory.\n\
J draws a Gold and a Province.\n\
J gets +1 Action.\n\
J plays a Witch.\n\
J draws 2 Provinces.\n\
J plays a Gold and 2 Silvers. (+$7)\n\
J buys and gains a Duchy.\n\
J shuffles their deck.\n\
J draws a Silver, a Duchy, a Province and 2 Villages.\n\
\n\
Turn 23 - Lord Rattington\n\
L plays a Witch.\n\
L draws 2 cards.\n\
L plays a Gold and 2 Silvers. (+$7)\n\
L buys and gains a Duchy.\n\
L draws 5 cards.\n\
\n\
Turn 24 - Jazzercise\n\
J plays a Village.\n\
J draws a Witch.\n\
J gets +2 Actions.\n\
J plays a Village.\n\
J draws a Silver.\n\
J gets +2 Actions.\n\
J plays a Witch.\n\
L reacts with a Moat.\n\
J draws a Village and a Witch.\n\
J plays a Village.\n\
J draws a Province.\n\
J gets +2 Actions.\n\
J plays a Witch.\n\
L reacts with a Moat.\n\
J draws a Province and a Chapel.\n\
J plays 2 Silvers. (+$4)\n\
J buys and gains an Estate.\n\
J draws a Gold, a Province, a Laboratory and 2 Villages.\n\
\n\
Turn 24 - Lord Rattington\n\
L plays a Laboratory.\n\
L shuffles their deck.\n\
L draws 2 cards.\n\
L gets +1 Action.\n\
L plays a Moat.\n\
L draws 2 cards.\n\
L plays a Gold and 3 Silvers. (+$9)\n\
L buys and gains a Province.\n\
L draws 5 cards.\
"
