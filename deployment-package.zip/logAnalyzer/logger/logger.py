def logError(message):
  print('ERROR:')
  print(message)
