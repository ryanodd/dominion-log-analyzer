A python server for AWS, deployed as a .zip
it consumes game logs for Dominion, and returns some stats.
